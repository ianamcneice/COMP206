#ifndef LIST_H_
#define LIST_H_

#define BOOLEAN int
#define TRUE 1
#define FALSE 0

void add(int i);
void prettyPrint();
BOOLEAN delete(int i);

#endif
